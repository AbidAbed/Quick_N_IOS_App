function useUploadAvatar() {
  async function uploadAvatar() {
    try {
    } catch (err) {}
  }
  return;
}
