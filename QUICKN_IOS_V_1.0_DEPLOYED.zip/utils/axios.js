import axios from "axios";

export const axiosObj = axios.create({
  // baseURL: "http://localhost:5000/api/v1",
  // baseURL: "http://localhost:5000/api/v1",
  
  baseURL: "https://novel-era.co/quickn/api/v1",
});
